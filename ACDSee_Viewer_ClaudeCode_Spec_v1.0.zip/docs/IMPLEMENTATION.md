# IMPLEMENTATION PHASES

0. Environment, architecture, skeleton and tests.
1. Application shell: window, menus, theme, status bar, tabs.
2. Explorer: enumeration, virtualization, sorting, selection, rename/delete.
3. Tabs/session: 25 tabs, persistence, atomic save, recovery.
4. Image engine: decoding, metadata, orientation, thumbnails, cache.
5. Viewer: sequential, random, history, keyboard, exit, F6, status.
6. Archives: ZIP, RAR, virtual folders, image viewing.
7. File operations: Copy/Move/Copy To/Move To/progress/cancel.
8. Conflicts: previews, comparisons, Replace/Rename/Skip/Cancel/Apply all.
9. Favorites.
10. SQLite statistics.
11. Intro Counter — BLOCKED until unresolved ranges are clarified.
12. Random Explorer.
13. Reliability/recovery.
14. Performance benchmarking/optimization.
15. Packaging and clean-machine test.

Do not jump directly to a complete implementation.
