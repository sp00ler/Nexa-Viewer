# VIEWER

## Standard counter
Format `TOTAL/CURRENT`, e.g. `469/69`. User-visible positions are always 1-based.

## Viewer status
Show available total/current, size, dimensions, type, full path in title and useful EXIF. Hide empty EXIF fields.

## Scaling
Fit down large images proportionally; do not upscale small images by default; preserve aspect ratio; respect EXIF orientation.

## Random history
Random navigation is history, not repeated random generation. Example 35 -> 102 -> 17 -> 88; Backspace returns 17 -> 102 -> 35.

## Exit
Esc and Enter exit Viewer and restore Explorer selection to the exact active image.

## Intro Counter
Format `X(Y)/Z`:
- X = current position within cycle
- Y = introductory physical-image count excluded from cycle
- Z = cycle length

Example 951:
- intro 20
- cycle 100
- physical 1..20 = introductory state
- physical 21 = `1(20)/100`
- physical 105 = `85(20)/100`
- warning starts at physical 105, 15 images before cycle end.

Example 469:
- intro 15
- cycle 50
- physical 16 = `1(15)/50`
- physical 50 = `35(15)/50` + warning.

## Current established ranges
| Total | Intro | Cycle |
|---:|---:|---:|
| 1–50 | 5 | special `-` state |
| 51–77 | ceil(N/10) | 5 |
| 78–127 | 10 | 5 |
| 128–177 | 15 | 7 |
| 178–227 | 20 | 10 |
| 228–299 | 10 | 30! |
| 300–799 | 15 | unresolved below |
| 800–1199 | 20 | ceil(N/10)*10 |
| >1199 | unresolved |

For N > 500 within 300–799: cycle = ceil(N/10)*10, intro = 15. Examples 505 -> 15/60, 645 -> 15/70.

For 800–1199: intro = 20, cycle = ceil(N/10)*10. Example 951 -> 20/100.

## BLOCKED
Do not invent exact 300–500 behavior or >1199 continuation. Ask the user before implementing those parts.
