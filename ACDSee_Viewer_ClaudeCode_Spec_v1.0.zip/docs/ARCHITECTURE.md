# ARCHITECTURE

Preferred stack: C#, .NET 10 LTS, WinUI 3/Windows App SDK, SQLite.

Suggested separation:
- UI
- Application
- Domain
- Infrastructure

Suggested abstractions:
`IFileContainer`, `IFileSystemService`, `IArchiveService`, `IImageDecoder`, `IImageMetadataReader`, `IThumbnailProvider`, `IViewerNavigationService`, `IFileOperationService`, `ICollisionResolver`, `IFavoritesService`, `ISessionService`, `IViewStatisticsService`, `ILoggingService`.

Physical directories and read-only archive containers should expose a common model where practical.

Never block UI with enumeration, archive scanning, decoding, thumbnail generation, hashing, DB work or file operations.

Use virtualization, lazy loading, bounded caches, limited Viewer prefetch and async/background work.

Session persistence must use atomic writes and recovery/backup where practical.

Keep transient thumbnail cache separate from SQLite.

Logging: normal transient log is deleted after clean shutdown; crash log survives abnormal termination.
