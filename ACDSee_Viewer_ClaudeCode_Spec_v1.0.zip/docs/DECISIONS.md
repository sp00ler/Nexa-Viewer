# ARCHITECTURAL DECISIONS

Record material decisions in this format:

## DECISION-XXXX — Title
Date:
Status:
Context:
Decision:
Alternatives:
Reason:
Consequences:
Tests/verification:

Initial decisions to document during Phase 0:
- UI stack
- image library
- archive libraries
- SQLite configuration
- session persistence format
- cache strategy
- logging framework
- packaging strategy
