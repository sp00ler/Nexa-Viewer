# PERFORMANCE

Measure actual builds; never invent performance claims.

Record hardware, OS, build configuration, runtime and dataset characteristics.

Benchmark startup, idle RAM/CPU, 1k/10k/100k folders, large ZIP/RAR, thumbnail generation, Viewer latency, Random Viewer, 25 tabs and SQLite growth.

Use bounded concurrency. Do not load complete collections into memory.

Document observed values, bottlenecks, optimizations and remaining limitations.
